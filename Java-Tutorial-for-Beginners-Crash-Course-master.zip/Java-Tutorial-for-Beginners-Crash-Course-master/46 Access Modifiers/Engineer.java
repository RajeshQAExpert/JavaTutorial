package com.telusko;

import com.telusko.test.Student;

public class Engineer extends Student
{
	public void show()
	{
		marks = 77;
		age = 55;
	}
}

package com.telusko;

import com.telusko.test.Student;

public class InnerDemo
{
	public static void main(String[] args)
	{
		Student s = new Student();
		s.rollno = 9;
		s.age=99;

	}
	
}


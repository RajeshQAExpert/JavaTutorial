package  com.telusko.test;

public class Student 
{
	int age=27;
	public int rollno=8;
	private String name="Navin";
	protected int marks = 56;
}

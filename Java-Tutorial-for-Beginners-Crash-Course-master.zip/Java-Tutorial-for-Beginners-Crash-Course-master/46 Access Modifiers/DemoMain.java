package com.telusko.test;

public class DemoMain 
{
	public static void main(String[] args)
	{
		Student s = new Student();
		s.rollno=9;
		s.marks=99;
		s.age=30;
	}

}
